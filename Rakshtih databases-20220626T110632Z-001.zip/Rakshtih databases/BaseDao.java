
package rakshith;

import java.sql.*;

public class BaseDao 
{
   Connection con;
    public BaseDao()
    {
    
    }

    public Connection getConnection()throws SQLException,ClassNotFoundException 
    {
      con = DriverManager.getConnection("jdbc:mysql://localhost:3306/databasname","username","password");
      return con;
    }

    public void closeConnection()throws SQLException,ClassNotFoundException 
    {
      con.close();
    }
};
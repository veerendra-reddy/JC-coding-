CREATE TABLE mytable1(
   id   VARCHAR(32) NOT NULL PRIMARY KEY
  ,name VARCHAR(21) NOT NULL
);
INSERT INTO mytable1(id,name) VALUES ('c31003c19bc840dbbd329d5af753079f','Mobiles & Accessories');
INSERT INTO mytable1(id,name) VALUES ('d38a55185e0b45cabde119fef0b0b165','Mobiles');
INSERT INTO mytable1(id,name) VALUES ('3997b81d2a614a999e191a59979da254','SAMSUNG Mobiles');
INSERT INTO mytable1(id,name) VALUES ('a5a4c19112844d5b888bb9a819674cc7','realme Mobiles');
INSERT INTO mytable1(id,name) VALUES ('6910608b3a1647fb9e8020364d47a925','APPLE Mobiles');
INSERT INTO mytable1(id,name) VALUES ('b6286b03057f40fda5d970e3d97b3c76','Infinix Mobiles');
INSERT INTO mytable1(id,name) VALUES ('2612f050c0b8425d880f5b74897ba1b2','POCO Mobiles');
INSERT INTO mytable1(id,name) VALUES ('cf847ad5ef314da7b8e176ef286e4d8c','REDMI Mobiles');
INSERT INTO mytable1(id,name) VALUES ('1c272064a9a549aca3e18c84858236a1','OPPO Mobiles');
INSERT INTO mytable1(id,name) VALUES ('fabe3cc5cfed457a8dfbf5054c4d3706','LAVA Mobiles');
INSERT INTO mytable1(id,name) VALUES ('9cf782a9cd7b4b06ae1f7b199e2164f1','Micromax Mobiles');
